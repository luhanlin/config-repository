package com.thomsonreuters.segment.helper;


import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author zlj
 */
public class QueueHelper {
	
	private static final Logger logger = LogManager.getLogger();

    public static final AtomicBoolean READ_FINISH_STATUS = new AtomicBoolean(false);

    public static final LinkedBlockingDeque<SegmentRecordEntity> INC_FULL_QUEUE = new LinkedBlockingDeque<>(1000000);

    public static final AtomicBoolean READ_RDC_FULL_FINISH_STATUS = new AtomicBoolean(false);

    public static final LinkedBlockingDeque<SegmentRecordEntity> RDC_FULL_QUEUE = new LinkedBlockingDeque<>(1000000);


    public static void addDataToQueueDefault(SegmentRecordEntity param){
        addDataToQueueDefault(param, INC_FULL_QUEUE);
    }

    public static void addDataToQueueDefault(SegmentRecordEntity param, LinkedBlockingDeque<SegmentRecordEntity> queue) {
        while (true){
            try {
                if (queue.offer(param, 5L, TimeUnit.SECONDS)) {
                    break;
                }
            } catch (Exception e) {
            	logger.error("queue add data error", e);
                throw new RuntimeException("queue add data error");
            }
        }
    }
}
