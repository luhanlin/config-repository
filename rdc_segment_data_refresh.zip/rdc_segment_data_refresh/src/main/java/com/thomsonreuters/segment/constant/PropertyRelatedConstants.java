package com.thomsonreuters.segment.constant;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-07 14:31
 **/
public class PropertyRelatedConstants {

    public static final long PROPERTY_ID_114840 = 114840;  // 134128

    public static final long PROPERTY_ID_114815 = 114815;

    public static final long PROPERTY_ID_116574 = 116574;

    public static final String ENTITY_TYPE_Q = "Q";

    // check range of time
    public static final String LIMIT_TIME = "2014-05-08 10:18:37";

    public static final String DATE_FORMAT_SIMPLE = "yyyyMMdd";

    public static final String DATE_FORMAT_USEFUL = "yyyy-MM-dd HH:mm:ss";

    //RDC_COLLECTED.RDC_FULL_STG_NEW
    //public static final String TABLE_NAME = "RDC_COLLECTED.RDC_FULL_STG";
}
