package com.thomsonreuters.segment.boot;

import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.helper.ThreadPoolHelper;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.processor.DifferentSegmentDataProcessor;
import com.thomsonreuters.segment.processor.SaveIncFullSegmentDataProcessor;
import com.thomsonreuters.segment.scan.ScanEdfIncFilesProcessor;
import com.thomsonreuters.segment.scan.ScanRdcFullFilesProcessor;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.IntStream;

/**
 * @author zlj
 */
@Log4j2
public class ProcessorStartApp {
	
	private static final Logger logger = LogManager.getLogger(ProcessorStartApp.class);

    public static void main(String[] args) {

        long start_time = System.currentTimeMillis();
        log.info("RDC processor start!!!");

        /**
         * 1. Init
         */
        InitialProcessor init = new InitialProcessor();
        init.init();

//        /**
//         * 2. save the data which we need
//         */
//        IntStream.range(0,6).forEach(i -> ThreadPoolHelper.addWriteQueueTask(new SaveRdcFullDataProcessor()));
//        log.info("SaveRdcFullDataProcessor start!!!");

//        log.info("SaveIncFullSegmentDataProcessor start!!!");
//        IntStream.range(0,12).forEach(i -> ThreadPoolHelper.addWriteQueueTask(new SaveIncFullSegmentDataProcessor()));

//        /**
//         * 3. scan RDC full files into RDC_PERMID_VALUE
//         */
//        log.info("ScanRdcFullFilesProcessor start!!!");
//        ScanRdcFullFilesProcessor fullProcess = new ScanRdcFullFilesProcessor();
//        fullProcess.processor();

//        /**
//         * 4. scan EDF increment files
//         */
//        log.info("ScanEdfIncFilesProcessor start!!!");
//        ScanEdfIncFilesProcessor incProcess = new ScanEdfIncFilesProcessor();
//        incProcess.processor();
//
//        ThreadPoolHelper.awaitReadComplete();
//        QueueHelper.READ_RDC_FULL_FINISH_STATUS.set(true);
//        QueueHelper.READ_FINISH_STATUS.set(true);
//
//        long endTime = System.currentTimeMillis();
//        log.info("scan all full file cost Time:" + (endTime - start_time));
//
//        ThreadPoolHelper.awaitWriteComplete();
//        ThreadPoolHelper.shutdown();

        /**
         * 5. Query the records which have the same permid with difference value.
         */
        log.info("DifferentSegmentDataProcessor execute!!!");
        DifferentSegmentDataProcessor differentProcessor = new DifferentSegmentDataProcessor();
        differentProcessor.process();

        logger.info("segment processor ended!!!");

        long spendTime = System.currentTimeMillis() - start_time;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
        System.out.println("total time：" + format.format(new Date(spendTime)));
    }
}
