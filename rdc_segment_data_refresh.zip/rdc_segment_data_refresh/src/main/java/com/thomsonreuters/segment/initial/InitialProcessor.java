package com.thomsonreuters.segment.initial;

import com.thomsonreuters.segment.utils.BlankUtil;
import com.thomsonreuters.segment.utils.PropertyUtil;
import lombok.extern.log4j.Log4j2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author zlj
 */
@Log4j2
public class InitialProcessor {

    public static final String EDF_FILE_PATH = "edfFilePath";
    public static final String RDC_FULL_FILE_PATH = "rdcFullFilePath";
    public static final String ENTITY_TYPE = "EntityType";
    public static final String QUERY_TABLE = "QueryTable";
    public static final String PROPERTY_ID = "PropertyId";
    public static final String FILE_NAME = "map.txt";

    public static String edfFilePath;
    public static String rdcFullFilePath;
    public static String queryTable;
    public static long propertyId;

    public static String entityTypeArr[] = null;

    public static List<String> entity_type_List = new ArrayList<>();

    // store the map of (nda_pi and segment true value)
    public static final Map<String, String> valueMap = new ConcurrentHashMap<>();

    public void init() {
        queryTable = PropertyUtil.getValue(QUERY_TABLE);
        propertyId = Long.valueOf(PropertyUtil.getValue(PROPERTY_ID));
        edfFilePath = PropertyUtil.getValue(EDF_FILE_PATH);
        rdcFullFilePath = PropertyUtil.getValue(RDC_FULL_FILE_PATH);
        entityTypeArr = PropertyUtil.getValue(ENTITY_TYPE).split(",");
        entity_type_List = Arrays.asList(entityTypeArr);
        try {
            initValueMap();
        } catch (IOException e) {
            e.printStackTrace();
            log.error("valueMap init fail.");
            throw new RuntimeException("valueMap init fail.");
        }
    }

    private void initValueMap() throws IOException {
        InputStream in = InitialProcessor.class.getClassLoader().getResourceAsStream(FILE_NAME);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        String line;

        while (!BlankUtil.isBlank(line = reader.readLine())) {
            Optional.ofNullable(line)
                    .ifPresent(s -> {
                        String[] split = s.split(",");

                        if (!BlankUtil.isBlank(split) && split.length == 2) {
                            valueMap.put(split[0], split[1]);
                        }
                    });
        }

    }
}
