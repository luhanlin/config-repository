package com.thomsonreuters.segment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 读取文件信息配置类
 * @author: Mr.Lu
 * @create: 2019-03-05 13:06
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SegmentRecordEntity {

    String permid;
    String value;

}
