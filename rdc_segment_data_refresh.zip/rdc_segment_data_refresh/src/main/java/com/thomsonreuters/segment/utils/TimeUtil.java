package com.thomsonreuters.segment.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TimeUtil {

    public static boolean dateCheck(String dataStr) {
        String eL = "^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])"
                + "|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?"
                + "((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|"
                + "(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3"
                + "0)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))";
        Pattern p = Pattern.compile(eL);
        Matcher m = p.matcher(dataStr);
        boolean b = m.matches();
        if (b) {
            return true;
        }
        return false;
    }

    /**
     * getExpireTime
     * @param minute
     * @return
     */
    public static Date getExpireTime(Integer minute){
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(System.currentTimeMillis());
        //设置超时
        cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + minute);
        Date time = cal.getTime();
        return time;
    }

    /**
     *
     * @param minute
     * @param format
     * @return
     */
    public static String getExpireTime(Integer minute, String format){
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(System.currentTimeMillis());
        //设置超时
        cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + minute);
        Date time = cal.getTime();
        String time_expire = new SimpleDateFormat(format).format(time);
        return time_expire;
    }

    /**
     * getBeforeDay
     * @param date
     * @param days
     * @return
     */
    public static Date getBeforeDay(Date date,Integer days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, days);
        date = calendar.getTime();
        return date;
    }

    /**
     * getBeforeTime
     * @param date
     * @param time
     * @return
     */
    public static Date getBeforeTime(Date date,Integer time,Integer calendarType) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(calendarType, time);
        date = calendar.getTime();
        return date;
    }

    /**
     *
     * @param cron
     * @return
     */
    public static Date getCronToDate(String cron) {
        String dateFormat="ss mm HH dd MM ? yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        Date date = null;
        try {
            date = sdf.parse(cron);
        } catch (ParseException e) {
            return null;
        }
        return date;
    }

    /**
     * @param date
     * @param dtFormat
     * @return
     */
    public static String fmtDateToStr(Date date, String dtFormat) {
        if (date == null)
            return "";
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(dtFormat);
            return dateFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static Date fmtStrToData(String date, String dtFormat) {
        if (date == null)
            return null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(dtFormat);
            return dateFormat.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get the time difference between the current time and 23:59:59
     */
    public static int time(){
        Calendar cal = Calendar.getInstance();
        int currentTime = (int) (cal.getTimeInMillis()/1000);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        int  expiryTime  = (int) (cal.getTimeInMillis()/1000);
        int  timeDifference = expiryTime-currentTime;
        return timeDifference;

    }
}
