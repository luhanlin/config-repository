package com.thomsonreuters.segment.processor;

import com.thomsonreuters.segment.constant.PropertyRelatedConstants;
import com.thomsonreuters.segment.entity.RdcRecordEntity;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.sql.ProcessorSql;
import com.thomsonreuters.segment.utils.BlankUtil;
import com.thomsonreuters.segment.utils.DruidUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.SQLException;
import java.util.List;

/**
 * @description: read rdc full perm_id and value
 * @author: Mr.Lu
 * @create: 2019-03-07 13:55
 **/
@Log4j2
public class SaveRdcSegmentDataProcessor implements Runnable {

    // Dbutils queryRunner
    private final QueryRunner queryRunner = new QueryRunner(DruidUtils.getDatasource());

    private static final long QUERY_LIMIT = 100000;

    @Override
    public void run() {
        log.info("thread[{}] is running, do SaveRdcSegmentDataProcessor...",  Thread.currentThread().getName());
        //1. query list of 114840(nda_pi and value) Paging query
        long max_nda_pi = 0L;

        while(true){

            List<RdcRecordEntity> recordEntities = getRdcRecordByPage(InitialProcessor.propertyId, max_nda_pi);

            if (!BlankUtil.isBlank(recordEntities)) {
                log.info("do SaveRdcSegmentDataProcessor, recordEntities.size[{}]",  recordEntities.size());

                for (RdcRecordEntity record : recordEntities) {
                    long nda_pi = record.getNda_pi();
                    if (nda_pi > max_nda_pi){
                        max_nda_pi = nda_pi;
                    }
                    String perm_id = getPermid(PropertyRelatedConstants.PROPERTY_ID_114815, nda_pi);
                    String value = getValue(PropertyRelatedConstants.PROPERTY_ID_116574, record.getCurrent_value());
//                    updateRdcPermidValue(perm_id, value);
                }
            }

            if (BlankUtil.isBlank(recordEntities) || recordEntities.size() < QUERY_LIMIT){
                break;
            }
        }

        log.info("thread[{}] is finished, do SaveRdcSegmentDataProcessor...",  Thread.currentThread().getName());
    }

    private List<RdcRecordEntity> getRdcRecordByPage(long propertyId, long max_nda_pi) {
        log.info("Query rdcRecord start ... max_nda_pi : {}", max_nda_pi);
        List<RdcRecordEntity> entityList = null;
        StringBuffer sqlBuf = new StringBuffer();
        sqlBuf.append("SELECT T.NDA_PI, T.CURRENT_VALUE FROM " );
        sqlBuf.append(" (SELECT NDA_PI,CURRENT_VALUE FROM " );
        sqlBuf.append(InitialProcessor.queryTable);
        sqlBuf.append(" WHERE ENTITY_TYPE = 'Q' AND NDA_PI > ?  AND PROPERTY_ID = ? ORDER BY NDA_PI ) T ");
        sqlBuf.append(" WHERE ROWNUM <= ? ");

        try {
            entityList = queryRunner.query(sqlBuf.toString(), new BeanListHandler<>(RdcRecordEntity.class), max_nda_pi, propertyId, QUERY_LIMIT);
        } catch (SQLException e) {
            log.error("Query rdcRecord occurs error ... max_nda_pi : {}, msg : {}", max_nda_pi, e.getMessage());
        }

        return entityList;
    }

    private String getPermid(long propertyId, long nda_pi) {
        String perm_id = null;
        String sql = "SELECT CURRENT_VALUE FROM " + InitialProcessor.queryTable + " WHERE NDA_PI = ? AND PROPERTY_ID = ? AND ENTITY_TYPE = 'Q' ";
        try {
            perm_id = queryRunner.query(sql, new ScalarHandler<>(), nda_pi, propertyId);
        } catch (SQLException e) {
            log.error("Get perm_id of the propertyId[{}] and nda_pi[{}] occurs error", propertyId, nda_pi);
        }

        return perm_id;
    }

    private String getValue(long propertyId, String nda_pi) {
        String value = null;
        String sql = "SELECT CURRENT_VALUE FROM " + InitialProcessor.queryTable + " WHERE NDA_PI = ? AND PROPERTY_ID = ? AND ENTITY_TYPE = 'SG' ";
        try {
            value = queryRunner.query(sql, new ScalarHandler<>(), nda_pi, propertyId);
        } catch (SQLException e) {
            log.error("Get value of the propertyId[{}] and nda_pi[{}] occurs error", propertyId, nda_pi);
        }

        return value;
    }

    private void updateRdcPermidValue(String perm_id, String value) {
        if (BlankUtil.isBlank(perm_id) || BlankUtil.isBlank(value)){
            log.error("perm_id[{}] and value[{}] can not be null", perm_id, value);
            return;
        }
        try {
            queryRunner.update(ProcessorSql.updateRdcPermIdValueSql, perm_id, value);
            log.info("insert RDC_PERMID_VALUE successfully,perm_id[{}] ", perm_id);
        } catch (SQLException e) {
            log.error("insert RDC_PERMID_VALUE occurs occurs error,perm_id[{}] ", perm_id);
        }
    }

}
