package com.thomsonreuters.segment.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @description: file tool
 * @author: Mr.Lu
 * @create: 2019-03-19 10:00
 **/
public class FileUtils {

    /**
     * loop read file in which end with suffix
     * @param path
     * @param suffix
     * @return
     */
    public static List<File> getPathFileList(String path, String suffix){
        List<File> filePathsList = new ArrayList<>();
        File file = new File(path);
        getFileList(file, suffix, filePathsList);
        return filePathsList;

    }

    /**
     * read file loop
     * @param file
     * @param suffix
     * @param fileList
     */
    private static void getFileList(File file, String suffix, List<File> fileList) {
        File[] filePaths = file.listFiles();

        for (File s : filePaths) {
            if (s.isDirectory()) {
                getFileList(s, suffix, fileList);
            } else {
                if (s.isFile() && -1 != s.getName().lastIndexOf(suffix)) {
                    fileList.add(s);
                }
            }
        }
    }
}
