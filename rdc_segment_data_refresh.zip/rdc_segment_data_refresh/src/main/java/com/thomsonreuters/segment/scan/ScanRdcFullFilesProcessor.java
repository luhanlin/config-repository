package com.thomsonreuters.segment.scan;


import com.thomsonreuters.segment.extractor.RdcFullEntityExtractor;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.helper.ThreadPoolHelper;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.utils.FileUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections.CollectionUtils;

import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author zlj
 */
@Log4j2
public class ScanRdcFullFilesProcessor {

    private static final AtomicInteger counter = new AtomicInteger();

    List<File> filePathsList;

    public ScanRdcFullFilesProcessor() {
        filePathsList = FileUtils.getPathFileList(InitialProcessor.rdcFullFilePath, ".gz");
    }

    public void processor() {
//        long startTime = System.currentTimeMillis();

        if (CollectionUtils.isEmpty(filePathsList)) {
            log.info("there is nothing to read. path = " + InitialProcessor.rdcFullFilePath);
            QueueHelper.READ_RDC_FULL_FINISH_STATUS.set(true);
            return;
        }
        log.info("RdcFullFilePathsList.size = " + filePathsList.size());

        RdcFullEntityExtractor extractor = new RdcFullEntityExtractor();

        for (int i = 0; i < filePathsList.size(); i++) {
            File file = filePathsList.get(i);
            ThreadPoolHelper.addReadQueueTask(() ->{
                extractor.extract(file);
                log.info("file [{}] already completed store, count[{}]:", file.getName(), counter.incrementAndGet());
            });

        }
//        log.info("Actual completion of [{}] file write queue", counter.get());


    }
}
