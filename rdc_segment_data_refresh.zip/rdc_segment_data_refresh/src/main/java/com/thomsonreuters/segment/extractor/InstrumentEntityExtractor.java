package com.thomsonreuters.segment.extractor;

import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.utils.BlankUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.File;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static javax.xml.stream.XMLStreamConstants.END_ELEMENT;
import static javax.xml.stream.XMLStreamConstants.START_ELEMENT;

/**
 * @author zlj
 */
@Log4j2
public class InstrumentEntityExtractor {

    private static final Logger LOGGER = LogManager.getLogger(InstrumentEntityExtractor.class);

    public void extract(File file) {
        XMLStreamReader xmlStreamReader = null;
        LOGGER.info("Processing File Name is: " + file.getName());

        try {
            // read xml to queue
            ZipFile zipFile = new ZipFile(file);
            Enumeration entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry zipEntry = (ZipEntry) entries.nextElement();
                //Get the inputStream of the zipEntry from zipFile
                InputStream in = zipFile.getInputStream(zipEntry);
                xmlStreamReader = PublicExtractor.openXMLStreamReader(in);
                doZipExtractToQueue(xmlStreamReader);
            }
            log.info(file.getName() + " extract end.");
        } catch (Exception ex) {
            LOGGER.error("one file extract has error", ex);
        } finally {
            PublicExtractor.closeStream(xmlStreamReader);
        }
    }

    private void doZipExtractToQueue(XMLStreamReader reader) throws XMLStreamException {
        while (reader.hasNext()) {
            int eventType = reader.next();
            if (START_ELEMENT == eventType) {
                String localName = reader.getLocalName();
//                log.info("localName: {}", localName);
                if ("Quote".equalsIgnoreCase(localName)) {
                    doParseQuote(reader);
                }
            }
        }
    }

    private void doParseQuote(XMLStreamReader reader) throws XMLStreamException {
        String perm_id = null;
        String value = null;
        String localName;
        while (reader.hasNext()) {
            int eventType = reader.next();
            switch (eventType) {
                case END_ELEMENT:
                    localName = reader.getLocalName();
                    if ("Quote".equalsIgnoreCase(localName)) {
                        // add into the queue, enter the next entity
                        if (!BlankUtil.isBlank(perm_id)) {
                            QueueHelper.addDataToQueueDefault(new SegmentRecordEntity(perm_id, value));
                        }
                        return;
                    }
                    break;
                case START_ELEMENT:
                    localName = reader.getLocalName();
                    switch (localName){
                        case "QuoteId" :
                            perm_id = reader.getElementText();
                            break;
                        case "TradingSegmentId" :
                            value = reader.getElementText();
                            break;
                        default:
                    }
                    break;
                default:
            }
        }
    }


//    public static void readXmlToQueue(File file) throws IOException {
//
////        InputStream in = null;
//        Reader bufferedReader = null;
//        List<Element> elementList = null;
//        // read xml
//        try {
//            SAXReader reader = new SAXReader();
//            log.info("FileName = " + file.getName());
//
//            ZipFile zipFile = new ZipFile(file);
//            Enumeration entries = zipFile.entries();
//            while (entries.hasMoreElements()) {
//                ZipEntry zipEntry = (ZipEntry) entries.nextElement();
//                //Get the inputStream of the zipEntry from zipFile
//                InputStream in = zipFile.getInputStream(zipEntry);
//                bufferedReader = new BufferedReader(new InputStreamReader(in, "UTF-8"), 1024 * 1024);
//
//                Document document = reader.read(bufferedReader);
//                //Read child data node of all from xml document.
//                elementList = document.selectNodes("//env:Data");
//                log.info("file[{}] has [{}] data child.", zipEntry.getName(), elementList.size());
//                for (Element element : elementList) {
//                    Element quote = element.element("Quote");
//                    Element quoteId = quote.element("QuoteId");
//                    Element tradingSegmentId = quote.element("TradingSegmentId");
//                    if (!BlankUtil.isBlank(quoteId) && !BlankUtil.isBlank(quoteId.getText())) {
//                        SegmentRecordEntity segmentRecordEntity = new SegmentRecordEntity();
//                        segmentRecordEntity.setPermid(quoteId.getText());
//                        segmentRecordEntity.setValue(!BlankUtil.isBlank(tradingSegmentId) ? tradingSegmentId.getText() : null);
//                        QueueHelper.addDataToQueueDefault(segmentRecordEntity);
//                    }
//                }
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (bufferedReader != null) {
//                bufferedReader.close();
//            }
//        }
//    }
}
