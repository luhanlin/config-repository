package com.thomsonreuters.segment.utils;

import com.thomsonreuters.segment.conf.DruidConnection;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @description: Druid工具类
 * @author: Mr.Lu
 * @create: 2019-03-05 14:22
 **/
public class DruidUtils {

    private static Connection connection = null;
    //获取元数据
    public static DataSource getDatasource() {
        DataSource dataSource = DruidConnection.getInstance().getDataSource();
        return dataSource;
    }

    //获取链接
    public static Connection getConnection() {
        connection = DruidConnection.getInstance().getConnection();
        return connection;
    }

    //归还资源
    public void release() {
        try {
            if(connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
