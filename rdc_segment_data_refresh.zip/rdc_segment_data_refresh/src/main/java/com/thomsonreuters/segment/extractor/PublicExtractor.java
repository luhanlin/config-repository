package com.thomsonreuters.segment.extractor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.*;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipOutputStream;

/**
 * @author zlj
 */
public class PublicExtractor {
	
	private static final Logger log = LogManager.getLogger(PublicExtractor.class);

    /**
     * open XML StreamReader
     * @param in
     * @return
     * @throws IOException
     * @throws XMLStreamException
     */
    public static XMLStreamReader openXMLStreamReader(InputStream in) throws IOException, XMLStreamException {
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        return xmlInputFactory.createXMLStreamReader(new BufferedReader(
                new InputStreamReader(in, "UTF-8"), 1024 * 1024));
    }

    /**
     * close stream
     *
     * @param reader
     */
    public static void closeStream(XMLStreamReader reader) {
        if (Objects.nonNull(reader)) {
            try {
                reader.close();
            } catch (XMLStreamException e) {
                log.error("close stream error", e);
            }
        }
    }

    /**
     * close stream
     *
     * @param zOutPut
     */
    public void closeZOutPutStream(ZipOutputStream zOutPut) {
        if (Objects.nonNull(zOutPut)) {
            try {
                zOutPut.closeEntry();
            } catch (IOException e) {
                log.error("close zOutPut error", e);
            }
        }
        if (Objects.nonNull(zOutPut)) {
            try {
                zOutPut.close();
            } catch (IOException e) {
                log.error("close zOutPut error", e);
            }
        }
    }
}
