package com.thomsonreuters.segment.scan;


import com.thomsonreuters.segment.extractor.InstrumentEntityExtractor;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.helper.ThreadPoolHelper;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.utils.FileUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author zlj
 */
@Log4j2
public class ScanEdfIncFilesProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ScanEdfIncFilesProcessor.class);

    List<File> filePathsList;

    public ScanEdfIncFilesProcessor() {
        filePathsList = FileUtils.getPathFileList(InitialProcessor.edfFilePath, ".zip");
    }

    public void processor() {
        if (CollectionUtils.isEmpty(filePathsList)) {
            log.info("there is nothing to read.");
            QueueHelper.READ_FINISH_STATUS.set(true);
            return;
        }
        log.info("filePathsList.size = " + filePathsList.size());

        InstrumentEntityExtractor instrumentEntityExtractor = new InstrumentEntityExtractor();
        //UnderWriterInstrumentEntityExtractor instrumentEntityExtractor = new UnderWriterInstrumentEntityExtractor();
        
        AtomicInteger counter = new AtomicInteger();
        LOGGER.info("A total of [{}] files should be written to the queue", filePathsList.size());
        for (int i = 0; i < filePathsList.size(); i++) {
            File file = filePathsList.get(i);
            ThreadPoolHelper.addReadQueueTask(() -> {
                LOGGER.info("file [{}] start write to queue...", file.getName());
                instrumentEntityExtractor.extract(file);
                LOGGER.info("file [{}] stop write to queue [{}]:", file.getName(), counter.incrementAndGet());
            });
        }
//        LOGGER.info("Actual completion of [{}] file write queue", counter.get());
    }
}
