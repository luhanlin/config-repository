package com.thomsonreuters.segment.entity;

import lombok.Data;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-07 14:08
 **/
@Data
public class RdcRecordEntity {

    // nda_pi of 114840
    private long nda_pi;

    // current_value of 114840
    private String current_value;

}
