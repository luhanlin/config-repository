package com.thomsonreuters.segment.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zlj
 */
@Data
public class Config implements Serializable {
    
	private String name;
    private String value;
    private String desc;
}
