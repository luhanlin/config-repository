package com.thomsonreuters.segment.processor;

import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.sql.ProcessorSql;
import com.thomsonreuters.segment.utils.BlankUtil;
import com.thomsonreuters.segment.utils.DruidUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.dbutils.QueryRunner;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-05 13:25
 **/
@Log4j2
public class SaveIncFullSegmentDataProcessor implements Runnable {

    private static final AtomicLong alreadyWriteCount = new AtomicLong(0);

    private final QueryRunner queryRunner = new QueryRunner(DruidUtils.getDatasource());

    @Override
    public void run() {
        log.info("thread[{}] SaveIncFullSegmentDataProcessor is running.", Thread.currentThread().getName());

//        long alreadyWriteCount = 0L;
        LinkedBlockingDeque<SegmentRecordEntity> queue = QueueHelper.INC_FULL_QUEUE;
        while (true) {
            try {

                SegmentRecordEntity segmentRecordEntity = queue.poll();
                if (!BlankUtil.isBlank(segmentRecordEntity)) {

                    // connection datasource and save the data.
                    queryRunner.update(ProcessorSql.updateIncPermIdValueSql, segmentRecordEntity.getPermid(), segmentRecordEntity.getValue());
//                    log.info("perm_id: {} insert into inc_table, count: {}", segmentRecordEntity.getPermid(), alreadyWriteCount.getAndIncrement());
                    alreadyWriteCount.getAndIncrement();
                    continue;
                }
                if (QueueHelper.READ_FINISH_STATUS.get()) {
                    break;
                }
            } catch (Exception ex) {
                log.error("save inc full segment data processor has error", ex);
            }
        }
        log.info("Save inc full segment data end!! alreadySaveCount is [{}] :", alreadyWriteCount.get());
    }
}
