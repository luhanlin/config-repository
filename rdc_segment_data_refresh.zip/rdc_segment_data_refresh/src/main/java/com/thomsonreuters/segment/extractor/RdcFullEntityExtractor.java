package com.thomsonreuters.segment.extractor;

import com.thomsonreuters.segment.constant.PropertyRelatedConstants;
import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.utils.BlankUtil;
import lombok.extern.log4j.Log4j2;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.GZIPInputStream;

import static com.thomsonreuters.segment.constant.PropertyRelatedConstants.PROPERTY_ID_114815;
import static com.thomsonreuters.segment.constant.PropertyRelatedConstants.PROPERTY_ID_114840;
import static javax.xml.stream.XMLStreamConstants.END_ELEMENT;
import static javax.xml.stream.XMLStreamConstants.START_ELEMENT;

/**
 * @author zlj
 */
@Log4j2
public class RdcFullEntityExtractor {

    private static final AtomicLong atomicLong = new AtomicLong(1);

    public void extract(File file) {
        XMLStreamReader xmlStreamReader = null;
    	log.info("Rdc full processing file name is: " + file.getName());

        try {
            // read xml
//            readRdcFullXml(file);
            GZIPInputStream gis = new GZIPInputStream(new FileInputStream(file));
            xmlStreamReader = PublicExtractor.openXMLStreamReader(gis);
            doExtractToQueue(xmlStreamReader);

            log.info("extract end.");
        } catch (Exception ex) {
            log.error("one file extract has error", ex);
        } finally {
            PublicExtractor.closeStream(xmlStreamReader);
        }
    }

    /**
     * parse the xml to queue
     * @param reader
     */
    private void doExtractToQueue(XMLStreamReader reader) throws XMLStreamException {
        while (reader.hasNext()) {
            int eventType = reader.next();
            if (START_ELEMENT == eventType) {
                String entityName = reader.getLocalName();
                if ("entity".equals(entityName)) {
                    String type = reader.getAttributeValue(null, "type");
                    if (PropertyRelatedConstants.ENTITY_TYPE_Q.equalsIgnoreCase(type)){
                        doParseEntity(reader);
                    }
                }
            }
        }
    }

    private void doParseEntity(XMLStreamReader reader) throws XMLStreamException {
        String perm_id = null;
        String nda_pi = null;
        String localName;
        while (reader.hasNext()) {
            int eventType = reader.next();
            switch (eventType) {
                case END_ELEMENT:
                    localName = reader.getLocalName();
                    if ("entity".equalsIgnoreCase(localName)) {
                        // get the value from the file list, enter the next entity
                        if (!BlankUtil.isBlank(perm_id) && !BlankUtil.isBlank(nda_pi)) {
                            String value = InitialProcessor.valueMap.get(nda_pi);

                            if (!BlankUtil.isBlank(value)) {
                                // put into queue
//                                log.info("perm_id : {}, value : {} , count : {}", perm_id, value, atomicLong.getAndIncrement());
                                QueueHelper.addDataToQueueDefault(new SegmentRecordEntity(perm_id,value), QueueHelper.RDC_FULL_QUEUE);
                            }
                        }
                       return;
                    }
                    break;
                case START_ELEMENT:
                    localName = reader.getLocalName();
                    if ("property".equalsIgnoreCase(localName)) {
                        Long id = Long.valueOf(reader.getAttributeValue(null, "id"));

                        if (PROPERTY_ID_114840 == id) {
                            nda_pi = getNdaPi(reader);
                        }

                        if (PROPERTY_ID_114815 == id){
                            perm_id = getPermId(reader);
                            if (BlankUtil.isBlank(perm_id)) {
                                return;
                            }
                        }
                    }
                    break;
                default:
            }
        }
    }

    private String getNdaPi(XMLStreamReader reader) throws XMLStreamException {
        String localName;
        while (reader.hasNext()) {
            int eventType = reader.next();
            switch (eventType) {
                case END_ELEMENT:
                    localName = reader.getLocalName();
                    if ("property".equalsIgnoreCase(localName)) {
                        // enter the next property
                        return null;
                    }
                    break;
                case START_ELEMENT:
                    localName = reader.getLocalName();
                    if ("currValue".equalsIgnoreCase(localName)) {
                        return reader.getElementText();
                    }
                    break;
                default:
            }
        }
        return null;
    }

    private String getPermId(XMLStreamReader reader) throws XMLStreamException {
        String perm_id = null;
        String validTo = null;
        String localName;
        while (reader.hasNext()) {
            int eventType = reader.next();
            switch (eventType) {
                case END_ELEMENT:
                    localName = reader.getLocalName();
                    if ("property".equalsIgnoreCase(localName)) {
                        // enter the next property
                        if (!BlankUtil.isBlank(validTo)) {
                            perm_id = null;
                        }
                        return perm_id;
                    }
                    break;
                case START_ELEMENT:
                    localName = reader.getLocalName();
                    switch (localName){
                        case "currValue" :
                            perm_id = reader.getElementText();
                            break;
                        case "validTo" :
                            validTo = reader.getElementText();
                            break;
                        default:
                    }
                    break;
                default:
            }
        }
        return null;
    }

//    public static void main(String[] args) {
//        long startTime = System.currentTimeMillis();
//        new InitialProcessor().init();
//        RdcFullEntityExtractor extractor = new RdcFullEntityExtractor();
//
//        extractor.extract(new File("C:\\Users\\UC253590\\Desktop\\new\\test_file\\rdc_full\\test.gz"));
//
//        long endTime = System.currentTimeMillis();
//        System.out.println(" is end! the millis is : " + (endTime - startTime));
//    }

//    private void readRdcFullXml(File file) throws IOException {
//
//        Reader bufferedReader = null;
//        // read xml
//        try {
//            SAXReader reader = new SAXReader();
//            reader.addHandler( "/rdcData/entity", new RdcFullElementHandler());
//            log.info("FileName = " + file.getName());
//
//            GZIPInputStream gis = new GZIPInputStream(new FileInputStream(file));
//            bufferedReader = new BufferedReader(new InputStreamReader(gis, "UTF-8"), 10 * 1024 * 1024);
////            in = new BufferedInputStream(gis);
//
//            reader.read(bufferedReader);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (bufferedReader != null) {
//                bufferedReader.close();
//            }
//        }
//    }

}
