package com.thomsonreuters.segment.handler;

import com.thomsonreuters.segment.constant.PropertyRelatedConstants;
import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.helper.QueueHelper;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.utils.BlankUtil;
import com.thomsonreuters.segment.utils.TimeUtil;
import lombok.extern.log4j.Log4j2;
import org.dom4j.Element;
import org.dom4j.ElementHandler;
import org.dom4j.ElementPath;

import java.util.List;
import java.util.Optional;

import static com.thomsonreuters.segment.constant.PropertyRelatedConstants.*;


/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-19 13:14
 **/
@Log4j2
public class RdcFullElementHandler implements ElementHandler {

    @Override
    public void onEnd(ElementPath path) {
        String perm_id = null;
        String nda_pi = null;
        Element row = path.getCurrent();
        String type = row.attributeValue("type");

        // 1. get perm_id and nda_pi from the file entity
        if (PropertyRelatedConstants.ENTITY_TYPE_Q.equalsIgnoreCase(type)) {
            List<Element> list = row.selectNodes("//property");
            if (!BlankUtil.isBlank(list)) {
                for (Element element : list) {
                    long id = Long.valueOf(element.attributeValue("id"));
                    if (PROPERTY_ID_114840 == id) {
                        nda_pi = Optional.ofNullable(element.element("currValue"))
                                .map(Element::getTextTrim)
                                .orElse(null);
                    } else if (PROPERTY_ID_114815 == id){
                        // check the invalid of property  -- 114815
                        boolean isInvalid = Optional.ofNullable(element.element("validTo"))
//                                .map(Element::getTextTrim)
//                                .filter(validTo -> {
//                                    long validTime = TimeUtil.fmtStrToData(validTo, DATE_FORMAT_SIMPLE).getTime();
//                                    long limitTime = TimeUtil.fmtStrToData(LIMIT_TIME, DATE_FORMAT_USEFUL).getTime();
//                                    if (limitTime >= validTime) {
//                                        return true;
//                                    }
//                                    return false; })
                                .isPresent();

                        if (!isInvalid) {
                            // get perm_id -- 114815
                            perm_id = Optional.ofNullable(element.element("currValue"))
                                    .map(Element::getTextTrim)
                                    .orElse(null);
                        } else {
                            // skip the entity
                            break;
                        }
                    }
                }
            }
        }

        // 2. get the value from the file list
//        if (!BlankUtil.isBlank(perm_id) && !BlankUtil.isBlank(nda_pi)) {
//            String value = InitialProcessor.valueMap.get(nda_pi);
//
//            if (!BlankUtil.isBlank(value)) {
//                // put into queue
//                log.info("perm_id : {}, value : {} ", perm_id, value);
//                QueueHelper.addDataToQueueDefault(new SegmentRecordEntity(perm_id,value), QueueHelper.RDC_FULL_QUEUE);
//            }
//        }

        row.detach();
    }

    @Override
    public void onStart(ElementPath path) {
    }
}
