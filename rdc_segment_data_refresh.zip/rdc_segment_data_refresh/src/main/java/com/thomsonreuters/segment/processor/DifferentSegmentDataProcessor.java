package com.thomsonreuters.segment.processor;

import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.initial.InitialProcessor;
import com.thomsonreuters.segment.sql.ProcessorSql;
import com.thomsonreuters.segment.utils.DruidUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @description:  Process the records which have the same permid with difference value.
 * @author: Mr.Lu
 * @create: 2019-03-08 11:07
 **/
@Log4j2
public class DifferentSegmentDataProcessor {

    // Dbutils queryRunner
    private final QueryRunner queryRunner = new QueryRunner(DruidUtils.getDatasource());

    private final AtomicLong count = new AtomicLong(1);

    /**
     * do work
     */
    public void process() {
        log.info(" Process the difference data start...");

        try {
            List<SegmentRecordEntity> entityList = queryRunner.query(ProcessorSql.differenceDataSql, new BeanListHandler<>(SegmentRecordEntity.class));
            log.info("size: {}", entityList.size());
            entityList.parallelStream().forEach(entity -> {

//                OutParameter<String> out1=new OutParameter<>(Types.VARCHAR, String.class);
//                OutParameter<BigDecimal> out2=new OutParameter<>(Types.NUMERIC, BigDecimal.class);
//                OutParameter<java.util.Date> out3=new OutParameter<>(Types.TIMESTAMP, java.util.Date.class);
                try {
                    queryRunner.execute("{call RDC_COLLECTED.TRANS_SEGMENT_QUOTE_MSG(?,?,?)}",
                            InitialProcessor.propertyId, entity.getPermid(), entity.getValue());
                } catch (SQLException e) {
                    log.error("Call SegmentRecordEntity occurs error ... permid: {}, msg : {}", entity.getPermid(), e.getMessage());
                }
                log.info("count:{}", count.getAndIncrement());
            });
            log.info("Call SegmentRecordEntity successfully ");
        } catch (SQLException e) {
            log.error("Query SegmentRecordEntity occurs error ... msg : {}", e.getMessage());
        }


    }
}
