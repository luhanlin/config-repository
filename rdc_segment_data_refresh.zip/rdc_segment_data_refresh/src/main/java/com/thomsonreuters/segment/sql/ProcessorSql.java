package com.thomsonreuters.segment.sql;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-20 15:57
 **/
public class ProcessorSql {

    public static final String updateRdcPermIdValueSql = "INSERT INTO RDC_COLLECTED.RDC_PERMID_VALUE VALUES(?, ?) ";

    public static final String updateIncPermIdValueSql = "INSERT INTO RDC_COLLECTED.INC_FULL_PERMID_VALUE VALUES(?, ?) ";

    public static final String differenceDataSql = " SELECT M.PERMID, M.VALUE FROM RDC_COLLECTED.RDC_PERMID_VALUE M WHERE M.VALUE IS NOT NULL " +
            "AND NOT EXISTS ( SELECT 1 FROM RDC_COLLECTED.INC_FULL_PERMID_VALUE N WHERE M.PERMID = N.PERMID AND M.VALUE = N.VALUE) ";


}
