package com.thomsonreuters.segment.conf;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import lombok.extern.log4j.Log4j2;

import javax.sql.DataSource;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @description: Druid连接池工具类
 * @author: Mr.Lu
 * @create: 2019-03-05 14:20
 **/
@Log4j2
public class DruidConnection {

    private static Properties properties = null;
    private static DataSource dataSource = null;
    private volatile static DruidConnection instance = null;
    private Connection connection = null;

    //私有构造函数,防止实例化对象
    private DruidConnection() {

    }


    static {
        try {
            properties = new Properties();
            // 1.加载properties文件
            InputStream is = DruidConnection.class.getClassLoader().getResourceAsStream("druid.properties");
//            InputStream is = new BufferedInputStream(new FileInputStream("../config/druid.properties"));

            // 2.加载输入流
            properties.load(is);

            // 3.获取数据源
            dataSource = getDatasource();

            log.info("druid datasource load successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 用简单单例模式确保只返回一个链接对象
     *
     * @return
     */
    public static  DruidConnection getInstance() {
        if(instance == null) {
            synchronized (DruidConnection.class) {
                if(instance == null) {
                    instance = new DruidConnection();
                }
            }
        }
        return instance;
    }

    // 返回一个数据源
    public DataSource getDataSource() {
        return dataSource;
    }

    // 返回一个链接
    public Connection getConnection() {
        try {
            connection = dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    // 加载数据源
    private static DataSource getDatasource() {
        DataSource source = null;
        try {
            source = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return source;
    }
}
