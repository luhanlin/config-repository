package com.thomsonreuters.segment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-05 14:37
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestTable {

    private String value;
}
