package com.thomsonreuters.segment.helper;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author zlj
 */
@Log4j2
public class ThreadPoolHelper {
	
	private static final Logger logger = LogManager.getLogger(ThreadPoolHelper.class);
    /**
     * read inc file thread
     */
    private static final ThreadPoolExecutor READ_EXECUTOR = new ThreadPoolExecutor(6, 6,
            10000L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(),
            new ThreadFactoryBuilder().setNameFormat("read-inc-file-poll-%d").build());

    private static final List<Future<?>> FUTURE_STATES = new ArrayList<>();

    /**
     *  write thread
     */
    private static final ThreadPoolExecutor WRITE_EXECUTOR = new ThreadPoolExecutor(12, 12,
            10000L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(),
            new ThreadFactoryBuilder().setNameFormat("insert-data-poll-%d").build());

    private static final List<Future<?>> B_FUTURE_STATES = new ArrayList<>();

    /**
     * add Read inc Queue Task
     * @param task
     * @return
     */
    public static Future<?> addReadQueueTask(Runnable task) {
        Future<?> future = READ_EXECUTOR.submit(task);
        FUTURE_STATES.add(future);
        return future;
    }

    /**
     * await read inc complete
     */
    public static void awaitReadComplete() {
        for (Future future : FUTURE_STATES) {
            try {
                future.get();
            } catch (Exception e) {
            	logger.error("get read task state error", e);
            }
        }

        FUTURE_STATES.clear();
    }

    /**
     * add Write Queue Task
     * @param task
     * @return
     */
    public static Future<?> addWriteQueueTask(Runnable task) {
        Future<?> future = WRITE_EXECUTOR.submit(task);
        B_FUTURE_STATES.add(future);
        return future;
    }

    /**
     * await read complete
     */
    public static void awaitWriteComplete() {
        for (Future future : B_FUTURE_STATES) {
            try {
                future.get();
            } catch (Exception e) {
            	logger.error("get write task state error", e);
            }
        }
        B_FUTURE_STATES.clear();
    }

    /**
     * close thread pool
     */
    public static void shutdown() {
        READ_EXECUTOR.shutdown();
        WRITE_EXECUTOR.shutdown();
    }

}
