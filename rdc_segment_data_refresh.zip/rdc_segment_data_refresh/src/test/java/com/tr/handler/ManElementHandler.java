package com.tr.handler;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-19 13:14
 **/

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.ElementHandler;
import org.dom4j.ElementPath;

import java.util.Iterator;
import java.util.List;

/**
 * 定制的事件处理器
 * @author 佛山无影脚
 * @version 1.0
 * Jul 7, 2008  4:35:49 PM
 */
public class ManElementHandler implements ElementHandler {
    public String mdbName;//数据库名称 含路径
    // ­
    public ManElementHandler(){

    }

    public ManElementHandler(String mdbName){
        this.mdbName = mdbName;
    }

    public void onEnd(ElementPath path) {
        Element row = path.getCurrent();
        Element rowSet = row.getParent();
        Document document = row.getDocument();
        Element root = document.getRootElement();
        Iterator it = root.elementIterator();
        while(it.hasNext()){
            Element element = (Element)it.next();
            System.out.println(" name : " + element.elementText("name"));
//            saveMan(element, this.mdbName);
        }
        row.detach();
    }

    public void onStart(ElementPath path) {

    }
}
