package com.tr.test;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * @description: 解析zip文件
 * @author: Mr.Lu
 * @create: 2019-03-06 13:26
 **/
public class ZipTest {

    public static void main(String[] args) throws IOException, DocumentException {

        ZipFile zipFile = new ZipFile(new File("C:\\Users\\UC253590\\Desktop\\new\\test_file\\222.zip"));
        //遍历zipFile文件的ZipEntry实体，即xml文件
        Enumeration entries = zipFile.entries();
        while (entries.hasMoreElements()) {
            ZipEntry zipEntry = (ZipEntry) entries.nextElement();
            //从zipFile中获取zipEntry的输入流，即xml文件的输入流
            InputStream inputStream = zipFile.getInputStream(zipEntry);
            //以下使用dom4j解析xml文件
            SAXReader reader = new SAXReader();
            Document document = reader.read(inputStream);
            //读xml文档中datas节点的所有data子节点元素
            List<Element> list1 = document.selectNodes("//env:Data");
            System.out.println(list1.size());
            for (Element element : list1) {
                Element relationship = element.element("Relationship");
                Element relationObjectId = relationship.element("RelationObjectId");
                System.out.println("attributeValue():"+relationObjectId.attribute("effectiveFrom").getText());
            }
        }
    }
}
