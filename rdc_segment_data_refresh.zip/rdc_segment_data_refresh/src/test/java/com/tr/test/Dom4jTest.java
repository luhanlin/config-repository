package com.tr.test;

import org.dom4j.*;
import org.dom4j.io.SAXReader;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * @description: 解析xml测试
 * @author: Mr.Lu
 * @create: 2019-03-06 09:59
 **/
public class Dom4jTest {

    @Test
    public void testDom4j() throws DocumentException {
        //1、 创建一个读取XML文件的对象  用来读取指向XML文件的输入流
        SAXReader reader = new SAXReader();
        //2、创建一个输入流
        InputStream is = Dom4jTest.class.getClassLoader().getResourceAsStream("test.xml");
        //3、获取当前XML文档对象
        Document doc = reader.read(is);
        Element root = doc.getRootElement();

        //根据"/"路径获取元素
        List<Element> list = root.selectNodes("/companys/company/name");
        System.out.println(list.size());
        for (Element element : list) {
            System.out.println("name元素的值是:"+element.getText());
        }
        //根据"//"路径获取元素
        List<Element> list1 = root.selectNodes("//name");
        System.out.println(list1.size());
        for (Element element : list1) {
            System.out.println("name元素的值是:"+element.getText());
            /**
             * name元素的值是:万科A
             name元素的值是:恒大B
             name元素的值是:金地C
             name元素的值是:绿地D
             */
        }
        //根据 ".."获取父元素,根据 "."获取当前元素,
        Element companyEle = root.element("company");
        System.out.println(companyEle.attributeValue("id"));
        Element fat = (Element) companyEle.selectSingleNode("..");//Node
        //Element fat = (Element) companyEle.selectSingleNode(".");//Node
        System.out.println("父节点"+fat.getName());//companys
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        //根据"@"获取属性
        List<Attribute> list2 = root.selectNodes("//company//@id");
        System.out.println(list2.size()); //4
        for (Attribute attribute : list2) {
            System.out.print(attribute.getValue()+" ");//1001 1002 1003 1006
        }

    }

    @Test
    public void testDom4j2() throws DocumentException {
        //1、 创建一个读取XML文件的对象  用来读取指向XML文件的输入流
        SAXReader reader = new SAXReader();
        //2、创建一个输入流
        InputStream is = Dom4jTest.class.getClassLoader().getResourceAsStream("test2.xml");
        //3、获取当前XML文档对象
        Document doc = reader.read(is);
        Element root = doc.getRootElement();

//        Namespace np = root.getNamespace();
//        System.out.println(root.getNamespace().getPrefix());
//        System.out.println("//RelationObjectId:"+root.attribute("//RelationObjectId").getText());
//        System.out.println("name:"+root.attribute("name").getText());
//        System.out.println("visibility:" + root.attribute("visibility").getText());

        //根据"//"路径获取元素

        List<Element> list1 = root.selectNodes("//env:Data");
        System.out.println(list1.size());
        for (Element element : list1) {
            System.out.println("getStringValue():"+element.getStringValue().trim());
            System.out.println("getTextTrim():"+element.getTextTrim());

            Element relationship = element.element("Relationship");
            Element relationObjectId = relationship.element("RelationObjectId");
            System.out.println("attributeValue():"+relationObjectId.attribute("effectiveFrom").getText());
        }

    }


}
