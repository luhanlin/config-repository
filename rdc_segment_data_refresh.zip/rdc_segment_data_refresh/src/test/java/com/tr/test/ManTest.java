package com.tr.test;

/**
 * @description:
 * @author: Mr.Lu
 * @create: 2019-03-19 13:16
 **/
import java.io.*;

import com.thomsonreuters.segment.handler.RdcFullElementHandler;
import com.thomsonreuters.segment.initial.InitialProcessor;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.xml.sax.SAXException;

public class ManTest {

    public Element createManElement(Long id,String name){
        Element manElement = DocumentHelper.createElement("man");
        manElement.addElement("id").addText(id.toString());
        manElement.addElement("name").addText(name);
        return manElement;
    }

    /**
     * 数据写入xml文件
     * @param filePath 目标xml文件的存放路径
     * @return
     */
    public boolean writeXML(String filePath){
        XMLWriter out;
        try {

            /*
             * 创建XMLWriter对象，设置XML编码，解决中文问题。
             */
            OutputFormat outputFormat = OutputFormat.createPrettyPrint();
            outputFormat.setEncoding("GBK");
            out = new XMLWriter(new FileWriter(filePath),outputFormat);


            out.startDocument();
            Element rootElement = DocumentHelper.createElement("mans");
            out.writeOpen(rootElement);

            /*
             * 向mans节点写入子节点
             */
            for(int i=0 ; i<100000 ; i++){
                Element man = this.createManElement(new Long(i), "shuhang"+i);
                out.write(man);
                System.out.println(" the loop index is : " + i);
            }

            out.writeClose(rootElement);
            out.endDocument();

            out.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } catch (SAXException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 从xml文件中读取数据，并将数据写入Access数据
     * @param filePath xml文件的存放路径
     * @return
     */
    public boolean readXML(String filePath){

        RdcFullElementHandler manElementHandler = new RdcFullElementHandler();
        SAXReader reader = new SAXReader();
        reader.addHandler( "/rdcData/entity", manElementHandler);
        Document document = null;
        try {
            File file = new File(filePath);
            document = reader.read(file);
        } catch (DocumentException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static void main(String[] args) throws FileNotFoundException, DocumentException {
        long startTime = System.currentTimeMillis();
        ManTest mantest = new ManTest();
        new InitialProcessor().init();
//        mantest.writeXML("C:\\Users\\UC253590\\Desktop\\new\\test_file\\mans.xml");
        mantest.readXML("C:\\Users\\UC253590\\Desktop\\new\\test_file\\rdc_full\\test.xml");

//        SAXReader reader = new SAXReader();
//        Document root = reader.read(new FileInputStream(new File("C:\\Users\\UC253590\\Desktop\\new\\test_file\\mans.xml")));
//        List<Element> list = root.selectNodes("//name");
//        list.forEach(element -> System.out.println(element.getStringValue()));

        long endTime = System.currentTimeMillis();
        System.out.println(" is end! the millis is : " + (endTime - startTime));

    }
}
