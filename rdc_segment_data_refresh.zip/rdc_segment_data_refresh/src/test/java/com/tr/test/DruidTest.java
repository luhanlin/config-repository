package com.tr.test;

import com.thomsonreuters.segment.entity.SegmentRecordEntity;
import com.thomsonreuters.segment.sql.ProcessorSql;
import com.thomsonreuters.segment.utils.DruidUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.junit.Test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * @description: 测试数据源连接
 * @author: Mr.Lu
 * @create: 2019-03-05 14:43
 **/
@Log4j2
public class DruidTest {

    private static QueryRunner runner = new QueryRunner(DruidUtils.getDatasource());


    private static Connection connection = DruidUtils.getConnection();

    @Test
    public void testQuery() throws SQLException {
//        String sql = " SELECT * FROM TEST_TABLE ";
//        List<TestTable> result = runner.query(sql, new BeanListHandler<>(TestTable.class));
//        result.stream().forEach(test -> System.out.println(test.getValue()));

//        String sql = "select current_value from rdc_collected.rdc_full_stg where nda_pi = ? AND property_id = ? and entity_type = 'Q' ";
//        String current_value = runner.query(sql, new ScalarHandler<>(), 187409212, 134128);
//        System.out.println(current_value);

        String sql = "select SNAME from student";
        List<String> snames = runner.query(sql, new ColumnListHandler<String>("sname"));
        snames.forEach(System.out::println);

//        List<TestTable> testTables = new ArrayList<>();
//
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//
//        String sql = "SELECT * FROM TEST_TABLE";
//        ps = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//
//        rs = ps.executeQuery();
//
//        if(rs.next()){
//            rs.previous();
//            while(rs.next()){
//                String value = rs.getString("value");
//                testTables.add(new TestTable(value));
//            }
//        }
//
//        testTables.stream().forEach(test -> System.out.println(test.getValue()));
    }

    @Test
    public void testInsert() throws SQLException {
        String sql = "insert into edf_permid_value values(?, ?) ";
        int update = runner.update(sql, new Object[]{"123", "test value"});



        System.out.println(update);
    }

    @Test
    public void test002() throws SQLException {
        long start = System.currentTimeMillis();
        runner.execute("{call RDC_COLLECTED.RDC_INC2FULL_PRC_HIS(?,?,?,?,?)}", "12b9bc6b-3960-482d-b77d-ba2a43f73192", 99, 40000, 41000, 99);
//        int count = runner.execute("{call RDC_COLLECTED.RDC_INC2FULL_POST_PRC(?)}", "10008191");

//        conn.commit();

//        int count = runner.execute("{call RDC_COLLECTED.RDC_TRANS_API_PKG.RDC_INCFILE_TRANS_PRC(?,?,?,?,?,?)}",
//                "b4b8dd46-75ff-4b03-97e4-f219ddf1a2a6", 1, "DP_" + "b4b8dd46-75ff-4b03-97e4-f219ddf1a2a6", "DP_" + "b4b8dd46-75ff-4b03-97e4-f219ddf1a2a6", "b4b8dd46-75ff-4b03-97e4-f219ddf1a2a6", "DP_" + "b4b8dd46-75ff-4b03-97e4-f219ddf1a2a6");

        System.out.println(System.currentTimeMillis() - start);
//        Log4j2 log4j2 = DruidTest.class.getAnnotation(Log4j2.class);
//        System.out.println(log4j2.topic());
//        Target target = test.annotationType().getAnnotation(Target.class);
//        System.out.println(target.value().toString());

//        List<SegmentRecordEntity> entityList = runner.query(ProcessorSql.differenceDataSql, new BeanListHandler<>(SegmentRecordEntity.class));
//        System.out.println(entityList.size());
    }
}
